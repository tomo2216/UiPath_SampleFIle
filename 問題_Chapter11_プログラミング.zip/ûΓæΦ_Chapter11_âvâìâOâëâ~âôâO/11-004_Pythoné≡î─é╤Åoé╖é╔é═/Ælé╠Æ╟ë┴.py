def incrementValue(x, y=1):
	return x + y